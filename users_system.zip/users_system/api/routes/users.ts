import express, { Router } from "express";
import db from "../config/db";
import { counter } from "../interfaces/counters";

module.exports = Router()
  .get('/get-counter', async (req, res) => {
    //obtener counter si existe
    res.json({ counter: (await db.query(`SELECT * FROM "counters" WHERE id_user = ${req.body.user.id}`)).rows[0]?.counter })
  })
  .post('/increment-counter', async (req: express.Request, res: express.Response) => {
    //obteniendo counter de usario
    let counter: counter = (await db.query(`SELECT * FROM "counters" WHERE id_user = ${req.body.user.id}`)).rows[0]
    if (counter) {
      //incrementando counter si existe
      counter = (await db.query(`UPDATE "counters" SET counter = ${counter.counter + 1} WHERE id_user = ${counter.id_user} RETURNING *`)).rows[0]
    } else {
      //creando counter con valor a 1 si no existe
      counter = (await db.query(`INSERT INTO "counters" (id_user, counter) VALUES (${req.body.user.id}, 1) RETURNING *`)).rows[0]
    }
    //enviando al front el counter actualizado
    res.json({ counter: counter.counter })
  })
  .post('/decrement-counter', async (req: express.Request, res: express.Response) => {
    //obteniendo counter de usuario
    let counter: counter = (await db.query(`SELECT * FROM "counters" WHERE id_user = ${req.body.user.id}`)).rows[0]
    if (counter) {
      //restando counter si existe
      counter = (await db.query(`UPDATE "counters" SET counter = ${counter.counter - 1} WHERE id_user = ${counter.id_user} RETURNING *`)).rows[0]
    } else {
      //creando counter con valor a -1 si no existe
      counter = (await db.query(`INSERT INTO "counters" (id_user, counter) VALUES (${req.body.user.id}, -1) RETURNING *`)).rows[0]
    }

    //enviando al front el counter actualizado
    res.json({ counter: counter.counter })
  })