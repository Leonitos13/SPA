import { Router } from "express";
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import db from '../config/db'
import { user } from "../interfaces/users";
import { saltRounds, secretKey } from "../config/dotenv";



module.exports = Router()
  .get('/', async (req, res) => {
    //enviando todos los usuarios
    res.json((await db.query(`SELECT * FROM "users"`)).rows)
  })
  .get('/:id', async (req, res) => {
    //enviando usuario por id
    res.json((await db.query(`SELECT id, name, username FROM "users" WHERE id = ${req.params.id}`)).rows[0])
  })
  .post('/login', async (req, res) => {
    //buscando usuario por username
    const user: user | undefined = (await db.query(`SELECT * FROM "users" WHERE username = '${req.body.username}'`)).rows[0]

    //verificando que la contraseña coincida y que el usuario exista

    if (user && await bcrypt.compare(req.body.password, user.password)) {
      //creando token si la contraseña coincide
      const token = jwt.sign(user, secretKey, { expiresIn: '1h' });

      //mandando usuario logeado y token
      res.json({ user: user, token: token })
    } else {
      //mandando error de datos incorrectos
      res.status(200).json({ message: "Credenciales Inválidas. Inténtelo de nuevo." })
    }
  })
  .post('/register', (req, res) => {
    //encriptando contraseña
    bcrypt.hash(req.body.password, saltRounds, async (err, result) => {

      //creando lista de users para buscar username
      const usernames: Array<string> = []
      const users: Array<{ username: string }> = (await db.query(`SELECT username FROM "users"`)).rows
      users.map(user => {
        usernames.push(user.username)
      })


      if (usernames.indexOf(req.body.username) === -1) {
        //Insertando usuario si no existe

        const query = (await db.query(`INSERT INTO "users" (name, username, password) VALUES ('${req.body.name}', '${req.body.username}', '${result}') RETURNING *`)).rows[0]

        //creando token
        const token = jwt.sign(query, secretKey, { expiresIn: '1h' });

        //mandando usuario registrado y token
        res.json({ user: query, token: token })

      } else {
        //enviando error que usuario ya está registrado
        res.json({ message: "Usuario ya existe." })
      }
    })
  })