import { Router } from "express";

module.exports = Router()
  .all('/', (req, res) => {
    //enviando endpoints
    res.json({
      'ALL /': 'Documentación de la api',
      'GET /users': 'Obtener lista de todos los usuarios',
      'GET /users/:id': 'Obtener lista del usuario que coincida con el id',
      'POST /users/register': 'Registrar usuario si no existe',
      'POST /users/login': 'Devolver usuario logeado si el nombre de usuario y la contraseña coinciden',
      'GET /u/:id/get-counter': 'Obtiene un contador establecido por el usuario (Ruta protegida con JWT)',
      'POST /u/:id/increment-counter': 'Incrementa dicho contador (Ruta protegida con JWT)',
      'POST /u/:id/decrement-counter': 'Decrementa dicho contador (Ruta protegida con JWT)',
    })
  })
  .use('/users', require('./auth'))
  .use('/u/:id', require('./users'))
