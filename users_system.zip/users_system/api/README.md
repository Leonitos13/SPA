# INICIAR API

## INSTALAR DEPENDENCIAS

```sh
npm ci
```

## INICIAR DB

[Backup database](./dump.sql)

## ARRANCAR SERVER

```sh
npm run dev
```

## ENDPOINTS API EN

[DOCUMENTACIÓN](http://localhost:3001/)

## CLIENTE REACT

[APP REACT](../client/app/README.md)
