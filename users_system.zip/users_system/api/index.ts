import express from 'express';

/* Configurando Servidor de api en http://localhost:3001 */
express()
  .use(express.json())
  .use(require('./middlewares/middleware'))
  .use('/', require('./routes/routes'))
  .listen(3001, () => { console.log("Servidor Iniciado en: http://localhost:3001") })