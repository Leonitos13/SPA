import express from 'express'
import { verifyToken } from "../config/jwt"


module.exports = express()
  .use((req, res, next) => {
    //configurando CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Authorization');
    next();
  })
  //protegiendo rutas
  .use('/u/:id', verifyToken, (req, res, next) => {
    //verificando que el id de usuario de la url coincida con el id del jwt token
    if (req.body.user.id === parseInt(req.params.id)) {
      next()
    } else {
      res.json({ message: "Usuario no tiene acceso a esta página" })
    }
  })