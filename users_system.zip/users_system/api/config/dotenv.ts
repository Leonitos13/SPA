import dotenv from 'dotenv'
//cargando variables de entorno
dotenv.config()

//cargando Saltrounds para la encriptación de contraseñas con bcrypt
let saltRounds: number
if (!process.env.SALT_ROUNDS) {
  throw new Error("No se ha proporcionado las SALT_ROUNDS")
} else {
  saltRounds = parseInt(process.env.SALT_ROUNDS)
}


//cargando secretKey para tokens JWT
let secretKey: string
if (!process.env.SECRET_KEY) {
  throw new Error('No se ha definido JWT_SECRET en las variables de entorno');
} else {
  secretKey = process.env.SECRET_KEY.toString()
}

export {
  saltRounds,
  secretKey
}