import { Pool } from 'pg';

//configurando DB PostgreSQL
const db = new Pool({
  user: 'admin',
  host: 'localhost',
  database: 'users-system',
  password: '123',
  port: 5432,
});

export default db