import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { secretKey } from './dotenv';

export const verifyToken = (req: Request, res: Response, next: NextFunction) => {
  //recibiendo token desde el header 'Authorization'
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  //verificando la existencia de dicho token en el header 'Authorization'
  if (!token) {
    return res.json({ message: 'Token no proporcionado' });
  }
  try {
    //Verificando token
    const decodedToken = jwt.verify(token, secretKey);
    req.body.user = decodedToken;
    next();
  } catch (error) {
    res.json({ message: 'Token no válido' });
  }
};

module.exports = { verifyToken }