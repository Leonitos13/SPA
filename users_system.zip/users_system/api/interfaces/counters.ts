//definiendo interface de counter

interface counter {
  id_user: number,
  counter: number
}

export { counter }