//definiendo interface de user

interface user {
  id: number,
  name: string,
  username: string,
  password: string,
}

export { user }