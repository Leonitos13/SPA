import React from "react";
import { Route, Routes } from "react-router-dom";

import Login from "./Login";
import Counter from "./Counter";

function App() {
  //configurando rutas
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/user/:id/counter" element={<Counter />} />
    </Routes>
  );
}

export default App;
