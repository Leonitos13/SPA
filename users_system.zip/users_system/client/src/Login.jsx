import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

const Login = () => {
  useEffect(() => {
    //reiniciando token cuando entra a la página de login
    if (localStorage.getItem("JWT")) {
      localStorage.removeItem("JWT");
    }
  }, []);

  //usando form hook
  const { register, handleSubmit } = useForm();
  //usando state para errores en registro y en login
  const [errorRegister, setErrorRegister] = useState("");
  const [errorLogin, setErrorLogin] = useState("");

  const signin = async (data) => {
    //reinizializando variables
    setErrorRegister(" ");
    if (data.password !== data.confirmationPassword) {
      //devolviendo error si la contraseña y su confirmación no coinciden
      setErrorRegister("Contraseñas no coinciden");
    } else {
      //sanitanizando datos
      const firstName = data.firstName.replace(" ", "").toLowerCase();
      const lastName = data.lastName.replace(" ", "").toLowerCase();
      const username = data.username.replace(" ", "").toLowerCase();
      //registrando usuario si no existe
      const response = await (
        await fetch("http://localhost:3001/users/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          //mandando body con escape de strings
          body: JSON.stringify({
            name: `${encodeURIComponent(
              firstName.charAt(0).toUpperCase() + firstName.slice(1)
            )} ${encodeURIComponent(
              lastName.charAt(0).toUpperCase() + lastName.slice(1)
            )}`,
            username: `${encodeURIComponent(username)}`,
            password: data.password,
          }),
        })
      ).json();
      if (response.message) {
        //poniendo error de usuario ya existe
        setErrorRegister("Nombre de usuario ya existe. Ingrese a su cuenta.");
      } else {
        //guardando token JWT en localStorage
        localStorage.setItem("JWT", response.token);
        //redireccionando al counter del usuario
        window.location.href = `/user/${response.user.id}/counter`;
      }
    }
  };
  const login = async (data) => {
    //reinizializando variables
    setErrorLogin(" ");
    const username = data.Lusername.replace(" ", "").toLowerCase();
    const response = await (
      await fetch("http://localhost:3001/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        //mandando datos para login con escape de strings
        body: JSON.stringify({
          username: `${encodeURIComponent(username)}`,
          password: data.Lpassword,
        }),
      })
    ).json();
    if (response.message) {
      //poniendo error de credenciales inválidas
      setErrorLogin("Credenciales Inválidas, Inténtelo de nuevo");
    } else {
      //guardando token JWT en LocalStorage
      localStorage.setItem("JWT", response.token);
      //redireccionando al counter del usuario
      window.location.href = `/user/${response.user.id}/counter`;
    }
  };
  //renderizando formularios
  return (
    <main className="container">
      <div className="col-12 col-md-8 row">
        <div className="col-12 text-center mb-3">
          <i className="fa fa-users fa-3x"></i>
        </div>
        <div className="col-12 col-md mb-3 mb-md-0">
          <h3 className="h3 mb-3">Registro</h3>
          <form onSubmit={handleSubmit(signin)}>
            <div className="text-center w-100 mb-3">
              <span className="text-warning fw-bold">{errorRegister}</span>
            </div>
            <div className="input-group mb-3">
              <input
                type="text"
                className="form-control"
                placeholder="Primer Nombre"
                {...register("firstName")}
              />
              <input
                type="text"
                className="form-control"
                placeholder="Primer Apellido"
                {...register("lastName")}
              />
            </div>
            <div className="input-group mb-3">
              <i className="input-group-text fa fa-user"></i>
              <input
                type="text"
                className="form-control"
                placeholder="Nombre de usuario"
                {...register("username")}
              />
            </div>
            <div className="input-group mb-3">
              <i className="input-group-text fw-bold fa fa-lock"></i>
              <input
                type="password"
                className="form-control"
                placeholder="Contraseña"
                {...register("password")}
              />
            </div>
            <div className="input-group mb-3">
              <i className="input-group-text fw-bold fa fa-lock"></i>
              <input
                type="password"
                className="form-control"
                placeholder="Confirmar contraseña"
                {...register("confirmationPassword")}
              />
            </div>
            <input
              type="submit"
              className="btn btn-outline-light w-100"
              value="Registrarse"
            />
          </form>
        </div>
        <div className="col-auto d-none d-md-block border-start border-white p-0"></div>
        <div className="col-12 col-md">
          <h3 className="h3 mb-3">Ingreso</h3>
          <form onSubmit={handleSubmit(login)}>
            <div className="text-center w-100 mb-3">
              <span className="text-warning fw-bold">{errorLogin}</span>
            </div>
            <div className="input-group mb-3">
              <i className="input-group-text fa fa-user"></i>
              <input
                type="text"
                className="form-control"
                placeholder="Nombre de usuario"
                {...register("Lusername")}
              />
            </div>
            <div className="input-group mb-3">
              <i className="input-group-text fw-bold fa fa-lock"></i>
              <input
                type="password"
                className="form-control"
                placeholder="Contraseña"
                {...register("Lpassword")}
              />
            </div>
            <input
              type="submit"
              className="btn btn-outline-light w-100"
              value="Ingresar"
            />
          </form>
        </div>
      </div>
    </main>
  );
};

export default Login;
