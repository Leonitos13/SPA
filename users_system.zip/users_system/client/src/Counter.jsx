import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const Counter = () => {
  //obteniendo el paramatero de la url
  const { id } = useParams();

  //poniendo el counter inicial = 0
  let [counter, setCounter] = useState(0);
  let [user, setUser] = useState({});

  useEffect(() => {
    //obteniendo counter para editar el state si counter existe
    async function fetchData() {
      const response = await (
        await fetch(`http://localhost:3001/u/${id}/get-counter`, {
          //mandando JWT por header 'Authorization' obtenido a través de LocalStorage del navegador
          headers: { Authorization: `Bearer ${localStorage.getItem("JWT")}` },
        })
      ).json();
      if (response.message) {
        //redireccionando si falla autenticación JWT
        window.location.href = "/";
      } else {
        //obteniendo user
        const user = await (
          await fetch(`http://localhost:3001/users/${id}`)
        ).json();
        //actualizando user
        setUser(user);
        if (response.counter) {
          setCounter(response.counter);
        }
        //actualizando counter
      }
    }
    fetchData();
  }, [id]);
  const increment = async () => {
    //obteniendo counter incrementado
    const response = await (
      await fetch(`http://localhost:3001/u/${id}/increment-counter`, {
        method: "POST",
        //mandando JWT por header 'Authorization' obtenido a través de LocalStorage del navegador
        headers: { Authorization: `Bearer ${localStorage.getItem("JWT")}` },
      })
    ).json();
    if (response.message) {
      //redireccionando si falla autenticación JWT
      window.location.href = "/";
    } else if (response.counter) {
      //actualizando counter
      setCounter(response.counter);
    }
  };
  const decrement = async () => {
    //obteniendo counter restado
    const response = await (
      await fetch(`http://localhost:3001/u/${id}/decrement-counter`, {
        method: "POST",
        //mandando JWT por header 'Authorization' obtenido a través de LocalStorage del navegador
        headers: { Authorization: `Bearer ${localStorage.getItem("JWT")}` },
      })
    ).json();
    if (response.message) {
      //redireccionando si falla autenticación JWT
      window.location.href = "/";
    } else if (response.counter) {
      //actualizando counter
      setCounter(response.counter);
    }
  };
  //renderizando elemento
  return (
    <main className="container">
      <div className="card bg-white text-primary col-12 col-md-8 row p-5">
        <div className="col-12 mb-5">
          <h3 className="h3">Contador de {decodeURIComponent(user.name)}</h3>
        </div>
        <div className="col-11 mx-auto row">
          <button className="col btn btn-danger" onClick={decrement}>
            <i className="fa fa-minus fa-5x"></i>
          </button>
          <div className="col d-flex align-items-center justify-content-center">
            <h1 className="h1 text-center" style={{ fontSize: 75 + "px" }}>
              {counter}
            </h1>
          </div>
          <button className="col btn btn-success" onClick={increment}>
            <i className="fa fa-plus fa-5x"></i>
          </button>
        </div>
      </div>
    </main>
  );
};

export default Counter;
